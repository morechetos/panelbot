<?php
$host = "[Database Host]";
$username = "[Database Username]";
$password="[Database Password]"; //Change this
$db_name="[Database Name]";
//--------------------- Don Not Change This ---------------------//
$conn = mysqli_connect($host,$username,$password,$db_name);
if(!$conn){
	die("No Connection!:".mysqli_connect_error());
}
//--------------------- Don Not Change This ---------------------//
?>
