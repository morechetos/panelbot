<!DOCTYPE html>
<html>
<head>
	<title>Add Fake Client</title>
</head>
<style type="text/css">
	
	table{
		width:25%;
		border: 1px solid black;
		border-collapse: collapse;
		padding: 15px;
		border-spacing: 5px;
	}
</style>
<body align="center" style="text-align: center;">
<form  method="GET" action="connection.php" align="center">
 <table align="center">
  <tr>
    <th>Add Fake Client</th>
  </tr>
  <tr>
    <td>Victim ID</td>
  </tr>
  <tr>
    <td><input type="input" id="VicID" name="VicID"></td>
  </tr>
    <tr>
    <td>IP Address</td>
  </tr>
  <tr>
    <td><input type="input" id="ipadress" name="ipadress"></td>
  </tr>
      <tr>
    <td>PC Name</td>
  </tr>
  <tr>
    <td><input type="input" id="ipadress" name="pcname"></td>
  </tr>
    <tr>
    <td>Operating system</td>
  </tr>
  <tr>
    <td><input type="input" id="os" name="os"></td>
  </tr>
      <tr>
    <td>CPU</td>
  </tr>
  <tr>
    <td><input type="input" id="os" name="cpu"></td>
  </tr>
      <tr>
    <td>GPU</td>
  </tr>
  <tr>
    <td><input type="input" id="os" name="gpu"></td>
  </tr>
      <tr>
    <td>Antivirus</td>
  </tr>
  <tr>
    <td><input type="input" id="antivirus"  name="antivirus"></td>
  </tr>
  <tr>
    <td>Status</td>
  </tr>
  <tr>
    <td><input type="input" id="status"  name="status"></td>
  </tr>
</table> 
<br>
<button type="submit">Add Target</button>
</form>
</body>
</html>