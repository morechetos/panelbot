
<?php
function GetContery($code)
{
    switch ($code) {
        Case "AF":
        return "Afghanistan";
        break;
        
        Case "AX":
        return "Aland Islands";
        break;
        
        Case "AL":
        return "Albania";
        break;
        
        Case "DZ":
        return "Algeria";
        break;
        
        Case "AS":
        return "American Samoa";
        break;
        
        Case "AD":
        return "Andorra";
        break;
        
        Case "AO":
        return "Angola";
        break;
        
        Case "AI":
        return "Anguilla";
        break;
        
        Case "AG":
        return "Antiguaand Barbuda";
        break;
        
        Case "AR":
        return "Argentina";
        break;
        
        Case "AM":
        return "Armenia";
        break;
        
        Case "AW":
        return "Aruba";
        break;
        
        Case "AU":
        return "Australia";
        break;
        
        Case "AT":
        return "Austria";
        break;
        
        Case "AZ":
        return "Azerbaijan";
        break;
        
        Case "BS":
        return "Bahamas";
        break;
        
        Case "BH":
        return "Bahrain";
        break;
        
        Case "BD":
        return "Bangladesh";
        break;
        
        Case "BB":
        return "Barbados";
        break;
        
        Case "BY":
        return "Belarus";
        break;
        
        Case "BE":
        return "Belgium";
        break;
        
        Case "BZ":
        return "Belize";
        break;
        
        Case "BJ":
        return "Benin";
        break;
        
        Case "BM":
        return "Bermuda";
        break;
        
        Case "BT":
        return "Bhutan";
        break;
        
        Case "BO":
        return "Bolivia";
        break;
        
        Case "BA":
        return "Bosniaand Herzegovina";
        break;
        
        Case "BW":
        return "Botswana";
        break;
        
        Case "BV":
        return "Bouvet Island";
        break;
        
        Case "BR":
        return "Brazil";
        break;
        
        Case "IO":
        return "British Indian Ocean Territory";
        break;
        
        Case "BN":
        return "Brunei Darussalam";
        break;
        
        Case "BG":
        return "Bulgaria";
        break;
        
        Case "BF":
        return "BurkinaFaso";
        break;
        
        Case "BI":
        return "Burundi";
        break;
        
        Case "KH":
        return "Cambodia";
        break;
        
        Case "CM":
        return "Cameroon";
        break;
        
        Case "CA":
        return "Canada";
        break;
        
        Case "CV":
        return "Cape Verde";
        break;
        
        Case "KY":
        return "Cayman Islands";
        break;
        
        Case "CF":
        return "Central African Republic";
        break;
        
        Case "TD":
        return "Chad";
        break;
        
        Case "CL":
        return "Chile";
        break;
        
        Case "CN":
        return "China";
        break;
        
        Case "CX":
        return "Christmas Island";
        break;
        
        Case "CC":
        return "Cocos Islands";
        break;
        
        Case "CO":
        return "Colombia";
        break;
        
        Case "KM":
        return "Comoros";
        break;
        
        Case "CG":
        return "Congo";
        break;
        
        Case "CK":
        return "Costa Rica";
        break;
        
        Case "CR":
        return "Cted'Ivoire";
        break;
        
        Case "HR":
        return "Croatia";
        break;
        
        Case "CU":
        return "Cuba";
        break;
        
        Case "CW":
        return "Curaao";
        break;
        
        Case "CY":
        return "Cyprus";
        break;
        
        Case "CZ":
        return "Czech Republic";
        break;
        
        Case "DK":
        return "Denmark";
        break;
        
        Case "DJ":
        return "Djibouti";
        break;
        
        Case "DM":
        return "Dominica";
        break;
        
        Case "DO":
        return "Dominican Republic";
        break;
        
        Case "EC":
        return "Ecuador";
        break;
        
        Case "EG":
        return "Egypt";
        break;
        
        Case "SV":
        return "ElSalvador";
        break;
        
        Case "GQ":
        return "Equatorial Guinea";
        break;
        
        Case "ER":
        return "Eritrea";
        break;
        
        Case "EE":
        return "Estonia";
        break;
        
        Case "ET":
        return "Ethiopia";
        break;
        
        Case "FK":
        return "Falkland Islands";
        break;
        
        Case "FO":
        return "Faroe Islands";
        break;
        
        Case "FJ":
        return "Fiji";
        break;
        
        Case "FI":
        return "Finland";
        break;
        
        Case "FR":
        return "France";
        break;
        
        Case "GF":
        return "French Guiana";
        break;
        
        Case "PF":
        return "French Polynesia";
        break;
        
        Case "TF":
        return "French Southern Territories";
        break;
        
        Case "GA":
        return "Gabon";
        break;
        
        Case "GM":
        return "Gambia";
        break;
        
        Case "GE":
        return "Georgia";
        break;
        
        Case "DE":
        return "Germany";
        break;
        
        Case "GH":
        return "Ghana";
        break;
        
        Case "GI":
        return "Gibraltar";
        break;
        
        Case "GR":
        return "Greece";
        break;
        
        Case "GL":
        return "Greenland";
        break;
        
        Case "GD":
        return "Grenada";
        break;
        
        Case "GP":
        return "Guadeloupe";
        break;
        
        Case "GU":
        return "Guam";
        break;
        
        Case "GT":
        return "Guatemala";
        break;
        
        Case "GG":
        return "Guernsey";
        break;
        
        Case "GN":
        return "Guinea";
        break;
        
        Case "GW":
        return "Guinea-Bissau";
        break;
        
        Case "GY":
        return "Guyana";
        break;
        
        Case "HT":
        return "Haiti";
        break;
        
        Case "HM":
        return "Heard Island and McDonald Islands";
        break;
        
        Case "VA":
        return "HolySee";
        break;
        
        Case "HN":
        return "Honduras";
        break;
        
        Case "HK":
        return "Hong Kong";
        break;
        
        Case "HU":
        return "Hungary";
        break;
        
        Case "IS":
        return "Iceland";
        break;
        
        Case "IN":
        return "India";
        break;
        
        Case "ID":
        return "Indonesia";
        break;
        
        Case "IR":
        return "Iran";
        break;
        
        Case "IQ":
        return "Iraq";
        break;
        
        Case "IE":
        return "Ireland";
        break;
        
        Case "IL":
        return "Israel";
        break;
        
        Case "IT":
        return "Italy";
        break;
        
        Case "JM":
        return "Jamaica";
        break;
        
        Case "JP":
        return "Japan";
        break;
        
        Case "JO":
        return "Jordan";
        break;
        
        Case "KZ":
        return "Kazakhstan";
        break;
        
        Case "KE":
        return "Kenya";
        break;
        
        Case "KI":
        return "Kiribati";
        break;
        
        Case "KP":
        return "Korea";
        break;
        
        Case "KR":
        return "Korea";
        break;
        
        Case "KW":
        return "Kuwait";
        break;
        
        Case "KG":
        return "Kyrgyzstan";
        break;
        
        Case "LA":
        return "Lao People's Democratic Republic";
        break;
        
        Case "LV":
        return "Latvia";
        break;
        
        Case "LB":
        return "Lebanon";
        break;
        
        Case "LS":
        return "Lesotho";
        break;
        
        Case "LR":
        return "Liberia";
        break;
        
        Case "LY":
        return "Libya";
        break;
        
        Case "LI":
        return "Liechtenstein";
        break;
        
        Case "LT":
        return "Lithuania";
        break;
        
        Case "LU":
        return "Luxembourg";
        break;
        
        Case "MO":
        return "Macao";
        break;
        
        Case "MK":
        return "Macedonia";
        break;
        
        Case "MG":
        return "Madagascar";
        break;
        
        Case "MW":
        return "Malawi";
        break;
        
        Case "MY":
        return "Malaysia";
        break;
        
        Case "MV":
        return "Maldives";
        break;
        
        Case "ML":
        return "Mali";
        break;
        
        Case "MT":
        return "Malta";
        break;
        
        Case "MH":
        return "Marshall Islands";
        break;
        
        Case "MQ":
        return "Martinique";
        break;
        
        Case "MR":
        return "Mauritania";
        break;
        
        Case "MU":
        return "Mauritius";
        break;
        
        Case "YT":
        return "Mayotte";
        break;
        
        Case "MX":
        return "Mexico";
        break;
        
        Case "FM":
        return "Micronesia";
        break;
        
        Case "MD":
        return "Moldova";
        break;
        
        Case "MC":
        return "Monaco";
        break;
        
        Case "MN":
        return "Mongolia";
        break;
        
        Case "ME":
        return "Montenegro";
        break;
        
        Case "MS":
        return "Montserrat";
        break;
        
        Case "MA":
        return "Morocco";
        break;
        
        Case "MZ":
        return "Mozambique";
        break;
        
        Case "MM":
        return "Myanmar";
        break;
        
        Case "NA":
        return "Namibia";
        break;
        
        Case "NR":
        return "Nauru";
        break;
        
        Case "NP":
        return "Nepal";
        break;
        
        Case "NL":
        return "Netherlands";
        break;
        
        Case "NC":
        return "New Caledonia";
        break;
        
        Case "NZ":
        return "New Zealand";
        break;
        
        Case "NI":
        return "Nicaragua";
        break;
        
        Case "NE":
        return "Niger";
        break;
        
        Case "NG":
        return "Nigeria";
        break;
        
        Case "NU":
        return "Niue";
        break;
        
        Case "MP":
        return "Norfolk Island";
        break;
        
        Case "NO":
        return "Norway";
        break;
        
        Case "OM":
        return "Oman";
        break;
        
        Case "PK":
        return "Pakistan";
        break;
        
        Case "PW":
        return "Palau";
        break;
        
        Case "PS":
        return "Palestine";
        break;
        
        Case "PA":
        return "Panama";
        break;
        
        Case "PG":
        return "Papua New Guinea";
        break;
        
        Case "PY":
        return "Paraguay";
        break;
        
        Case "PE":
        return "Peru";
        break;
        
        Case "PH":
        return "Philippines";
        break;
        
        Case "PN":
        return "Pitcairn";
        break;
        
        Case "PL":
        return "Poland";
        break;
        
        Case "PT":
        return "Portugal";
        break;
        
        Case "PR":
        return "Puerto Rico";
        break;
        
        Case "QA":
        return "Qatar";
        break;
        
        Case "RE":
        return "Runion";
        break;
        
        Case "RO":
        return "Romania";
        break;
        
        Case "RU":
        return "Russian Federation";
        break;
        
        Case "RW":
        return "Rwanda";
        break;
        
        Case "SH":
        return "Saint Helena";
        break;
        
        Case "KN":
        return "Saint Kittsand Nevis";
        break;
        
        Case "LC":
        return "Saint Lucia";
        break;
        
        Case "PM":
        return "Saint Pierreand Miquelon";
        break;
        
        Case "VC":
        return "Saint Vincentandthe Grenadines";
        break;
        
        Case "WS":
        return "Samoa";
        break;
        
        Case "SM":
        return "San Marino";
        break;
        
        Case "ST":
        return "Sao Tomeand Principe";
        break;
        
        Case "SA":
        return "Saudi Arabia";
        break;
        
        Case "SN":
        return "Senegal";
        break;
        
        Case "RS":
        return "Serbia";
        break;
        
        Case "SC":
        return "Seychelles";
        break;
        
        Case "SL":
        return "Sierra Leone";
        break;
        
        Case "SG":
        return "Singapore";
        break;
        
        Case "SK":
        return "Slovakia";
        break;
        
        Case "SI":
        return "Slovenia";
        break;
        
        Case "SB":
        return "Solomon Islands";
        break;
        
        Case "SO":
        return "Somalia";
        break;
        
        Case "ZA":
        return "South Africa";
        break;
        
        Case "GS":
        return "SGSSI";
        break;
        
        Case "ES":
        return "Spain";
        break;
        
        Case "LK":
        return "SriLanka";
        break;
        
        Case "SD":
        return "Sudan";
        break;
        
        Case "SR":
        return "Suriname";
        break;
        
        Case "SJ":
        return "Svalbardand Jan Mayen";
        break;
        
        Case "SZ":
        return "Swaziland";
        break;
        
        Case "SE":
        return "Sweden";
        break;
        
        Case "CH":
        return "Switzerland";
        break;
        
        Case "SY":
        return "Syrian Arab Republic";
        break;
        
        Case "TW":
        return "Taiwan";
        break;
        
        Case "TJ":
        return "Tajikistan";
        break;
        
        Case "TZ":
        return "Tanzania";
        break;
        
        Case "TH":
        return "Thailand";
        break;
        
        Case "TL":
        return "Timor-Leste";
        break;
        
        Case "TG":
        return "Togo";
        break;
        
        Case "TK":
        return "Tokelau";
        break;
        
        Case "TO":
        return "Tonga";
        break;
        
        Case "TT":
        return "Trinidadand Tobago";
        break;
        
        Case "TN":
        return "Tunisia";
        break;
        
        Case "TR":
        return "Turkey";
        break;
        
        Case "TM":
        return "Turkmenistan";
        break;
        
        Case "TC":
        return "Turksand Caicos Islands";
        break;
        
        Case "TV":
        return "Tuvalu";
        break;
        
        Case "UG":
        return "Uganda";
        break;
        
        Case "UA":
        return "Ukraine";
        break;
        
        Case "AE":
        return "United Arab Emirates";
        break;
        
        Case "GB":
        return "United Kingdom";
        break;
        
        Case "US":
        return "United States";
        break;
        
        Case "UZ":
        return "Uzbekistan";
        break;
        
        Case "VU":
        return "Vanuatu";
        break;
        
        Case "VE":
        return "Venezuela";
        break;
        
        Case "VN":
        return "VietNam";
        break;
        
        Case "WF":
        return "Wallisand Futuna";
        break;
        
        Case "EH":
        return "Western Sahara";
        break;
        
        Case "YE":
        return "Yemen";
        break;
        
        Case "ZM":
        return "Zambia";
        break;
        
        Case "ZW":
        return "Zimbabwe";
        break;

        default:
            return "Unknown";
            break;
    }
}
?>